import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return np.exp(2 * x) * np.sin(3 * x)

def F(x):
  return (np.exp(2 * x) / 13.0) * (2 * np.sin(3 * x) - 3 * np.cos(3 * x))

def composite_trapezoidal(a, b, n):
  h = (b - a) / n
  total = f(a) + f(b)
  for j in range(1, n):
    total += 2 * f(a + j * h)
  return (h / 2) * total

def composite_simpsons(a, b, n):
  h = (b - a) / n
  even = 0.0
  odd = 0.0
  for k in range(1, n):
    if k % 2 == 0:
      even += 2 * f(a + k * h)
    else:
      odd += 4 * f(a + k * h)
  return (h / 3) * (f(a) + f(b) + even + odd)

a, b = 0.0, 2.0
exact = F(b) - F(a)

n_values = [4, 8, 16, 32, 64]
h_values = [(b - a) / n for n in n_values]

trap_results = [float(composite_trapezoidal(a, b, n)) for n in n_values]
trap_errors = [float(abs(exact - val)) for val in trap_results]

simp_results = [float(composite_simpsons(a, b, n)) for n in n_values]
simp_errors = [float(abs(exact - val)) for val in simp_results]

print("Exact Value:", exact)
print("Trapezoidal Results:", trap_results)
print("Trapezoidal Errors:", trap_errors)
print("Simpson's Results:", simp_results)
print("Simpson's Errors:", simp_errors)


plt.loglog(h_values, trap_errors)
plt.loglog(h_values, simp_errors)

plt.show()