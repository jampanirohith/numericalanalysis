import math

def f(x):
    return math.exp(-x*x)*(1+x*x+x**4)

def gauss_legendre(f, points, weights, a, b):
    result = 0

    for i in range(len(points)):
        x = (a+b)/2 + ((b-a)/2)*points[i]
        result += weights[i]*f(x)

    return ((b-a)/2)*result

a = 0
b = 1

# Two-point rule

points2 = [-1/math.sqrt(3), 1/math.sqrt(3)]
weights2 = [1, 1]

I2 = gauss_legendre(f, points2, weights2, a, b)

# Three-point rule

points3 = [-math.sqrt(3/5), 0, math.sqrt(3/5)]
weights3 = [5/9, 8/9, 5/9]

I3 = gauss_legendre(f, points3, weights3, a, b)

# Four-point rule

p = math.sqrt(6/5)

points4 = [
    -math.sqrt((3+2*p)/7),
    -math.sqrt((3-2*p)/7),
     math.sqrt((3-2*p)/7),
     math.sqrt((3+2*p)/7)
]

weights4 = [
    (18-math.sqrt(30))/36,
    (18+math.sqrt(30))/36,
    (18+math.sqrt(30))/36,
    (18-math.sqrt(30))/36
]

I4 = gauss_legendre(f, points4, weights4, a, b)

# Reference value

reference = 1.0365652767779367

print("Two-point Approximation =", I2)
print("Two-point Absolute Error =", abs(I2-reference))

print("\nThree-point Approximation =", I3)
print("Three-point Absolute Error =", abs(I3-reference))

print("\nFour-point Approximation =", I4)
print("Four-point Absolute Error =", abs(I4-reference))

print("\nReference Value =", reference)