import numpy as np
import matplotlib.pyplot as plt

def f(x):
    return np.exp(x)*np.sin(2*x) + pow(x,3)*np.log(x+1)

def d2f(x):
  term1 = np.exp(x) * (-3 * np.sin(2 * x) + 4 * np.cos(2 * x))
  term2 = (
      6 * x * np.log(x + 1) + (6 * (x**2)) / (x + 1) - (x**3) / ((x + 1) ** 2)
  )
  return term1 + term2

x = 0.5
exact = d2f(x)

D2 = {}
for k in range(1, 12):
    h = 2.0**(-k)
    D2[k] = (f(x + h) - 2 * f(x) + f(x - h)) / (h**2)

h_list = []
err_d2_list = []
err_r1_list = []
err_r2_list = []


print("k | h | D2 Error | R1 Error | R2 Error")

for k in range(1, 10):
    h = 2.0**(-k)
    
    d2_h = D2[k]
    d2_half = D2[k + 1]
    d2_quarter = D2[k + 2]
    
    r1_h = (4 * d2_half - d2_h) / 3
    r1_half = (4 * d2_quarter - d2_half) / 3
    
    r2_h = (16 * r1_half - r1_h) / 15
    
    err_d2 = abs(d2_h - exact)
    err_r1 = abs(r1_h - exact)
    err_r2 = abs(r2_h - exact)
    
    print(f"{k:<3} | {h:<9.6f} | {err_d2:<10.2e} | {err_r1:<10.2e} | {err_r2:<10.2e}")

plt.loglog(h_list, err_d2_list)
plt.loglog(h_list, err_r1_list)
plt.loglog(h_list, err_r2_list)

plt.show()