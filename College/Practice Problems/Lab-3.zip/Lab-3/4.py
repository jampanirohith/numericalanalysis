import numpy as np

def f(x):
  return np.exp(np.sin(x))

def df(x):
  return np.cos(x) * np.exp(np.sin(x))

def central_difference(x, h):
  return (f(x + h) - f(x - h)) / (2 * h)

x = np.pi / 6
exact = df(x)

N = 6
R = np.zeros((N, N))

for k in range(N):
  h_k = 1.0 / (2**k)
  R[k, 0] = central_difference(x, h_k)
  for j in range(1, k + 1):
    R[k, j] = R[k, j - 1] + (R[k, j - 1] - R[k - 1, j - 1]) / (4**j - 1)

E = np.abs(R - exact)

print(f"Exact f'(pi/6) = {exact:.12f}\n")

print("Richardson Extrapolation Table:")
for k in range(N):
  for j in range(k + 1):
    print(R[k, j],  end="\t")
  print()

print("\nAbsolute Errors:")
for k in range(N):
  for j in range(k + 1):
    print(E[k, j],  end="\t")
  print()
