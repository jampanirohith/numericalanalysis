import math

def f(x):
    return math.exp(-x*x) * math.cos(2*x)

def romberg(f, a, b, levels):
    R = []

    for k in range(levels):
        n = 2**k
        h = (b-a)/n

        T = (f(a) + f(b))/2

        for i in range(1, n):
            T += f(a + i*h)

        T *= h

        row = [T]

        for j in range(1, k+1):
            value = row[j-1] + (row[j-1] - R[k-1][j-1])/(4**j - 1)
            row.append(value)

        R.append(row)

    return R

a = 0
b = 1

R = romberg(f, a, b, 6)

print("Romberg Table")

for i in range(len(R)):
    print("n =", 2**i, end="  ")
    for j in range(len(R[i])):
        print("%0.12f" % R[i][j], end="  ")
    print()

reference = 0.4290977821350847

print("\nReference Value =", reference)
print("\nDiagonal Entries and Errors")

for i in range(len(R)):
    value = R[i][i]
    error = abs(value - reference)
    print("n =", 2**i, "Value =", value, "Error =", error)