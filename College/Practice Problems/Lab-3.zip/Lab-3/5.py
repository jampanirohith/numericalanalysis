import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return np.sin(x) / x

def d2f(x):
  return ((2 - x**2) * np.sin(x) - 2 * x * np.cos(x)) / (x**3)

def D2(x, h):
  return (f(x + h) - 2 * f(x) + f(x - h)) / (h**2)

x = 1
exact = d2f(x)

h_list = []
D_error = []
R_error = []

for k in range(1, 10):
  h = 2 ** (-k)
  h_list.append(h)

  d_val = D2(x, h)
  d_half = D2(x, h / 2)
  r_val = (4 * d_half - d_val) / 3

  D_error.append(np.abs(d_val - exact))
  R_error.append(np.abs(r_val - exact))

print("k\t h\t\t D2 Error\t Order D2\t R Error\t Order R")
print("-" * 75)

for i in range(9):
  k = i + 1
  if i == 0:
    order_D = "-"
    order_R = "-"
  else:
    order_D = round(np.log2(D_error[i - 1] / D_error[i]), 2)
    order_R = round(np.log2(R_error[i - 1] / R_error[i]), 2)

  print(
      k,
      "\t",
      round(h_list[i], 6),
      "\t",
      f"{D_error[i]:.2e}",
      "\t",
      order_D,
      "\t\t",
      f"{R_error[i]:.2e}",
      "\t",
      order_R,
  )


plt.loglog(h_list, D_error)
plt.loglog(h_list, R_error)

plt.show()
