import math
import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return np.log((x**2) + 1) + np.sin(x**2)

def centraldifference(x, h):
  return (f(x + h) - f(x - h)) / (2 * h)

def df(x):
  return (2 * x) / ((x**2) + 1) + 2 * x * np.cos(x**2)

x = 0.8
p = df(0.8)

h = []
cd = []
cd_error = []

for k in range(1, 9):
  h.append(10 ** (-k))

for i in range(0, 8):
  cd.append(centraldifference(x, h[i]))
  cd_error.append(np.abs(cd[i] - p))

print('h | Central Difference | Absolute Error\n')

for i in range(0, 8):
  if i == 0:
    print(h[i], ' | ', cd[i], ' | ', cd_error[i])
  else:
    print(h[i], ' | ', cd[i], ' | ', cd_error[i])

plt.loglog(h, cd_error)
plt.show()
