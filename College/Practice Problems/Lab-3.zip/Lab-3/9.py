import numpy as np
from scipy.integrate import quad

def f(x):
    return np.exp(x) * np.cos(2 * x) / (1 + x**2)

def composite_trapezoidal(a, b, n):
    h = (b - a) / n
    total = f(a) + f(b)
    for j in range(1, n):
        total += 2 * f(a + j * h)
    return (h / 2) * total

def composite_simpsons(a, b, n):
    h = (b - a) / n
    even = 0.0
    odd = 0.0
    for k in range(1, n):
        if k % 2 == 0:
            even += 2 * f(a + k * h)
        else:
            odd += 4 * f(a + k * h)
    return (h / 3) * (f(a) + f(b) + even + odd)

a, b = 0.0, 1.0
exact, _ = quad(f, a, b, epsabs=1e-14, epsrel=1e-14)

n_values = [4, 8, 16, 32, 64]

trap_results = [float(composite_trapezoidal(a, b, n)) for n in n_values]
trap_errors = [float(abs(exact - val)) for val in trap_results]

simp_results = [float(composite_simpsons(a, b, n)) for n in n_values]
simp_errors = [float(abs(exact - val)) for val in simp_results]

print("Exact Value:", exact)
print("Trapezoidal Results:", trap_results)
print("Trapezoidal Errors:", trap_errors)

print("Simpson's Results:", simp_results)
print("Simpson's Errors:", simp_errors)

