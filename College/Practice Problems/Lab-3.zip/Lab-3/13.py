import math

def f(x):
    return math.exp(x)/(1+x*x)

def gauss_legendre(f, points, weights, a, b):
    result = 0
    for i in range(len(points)):
        x = (a+b)/2 + ((b-a)/2)*points[i]
        result += weights[i]*f(x)

    return ((b-a)/2)*result

a = 0
b = 2

# Two-point Gauss-Legendre rule

points2 = [-1/math.sqrt(3), 1/math.sqrt(3)]
weights2 = [1, 1]

I2 = gauss_legendre(f, points2, weights2, a, b)

# Three-point Gauss-Legendre rule

points3 = [-math.sqrt(3/5), 0, math.sqrt(3/5)]
weights3 = [5/9, 8/9, 5/9]

I3 = gauss_legendre(f, points3, weights3, a, b)

reference = 2.663193137959489

print("Two-point Approximation =", I2)
print("Two-point Absolute Error =", abs(I2-reference))

print("\nThree-point Approximation =", I3)
print("Three-point Absolute Error =", abs(I3-reference))

print("\nReference Value =", reference)