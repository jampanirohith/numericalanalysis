import math

def f(x):
    return (x*x * math.exp(-x))/(1+x*x)

def romberg(f, a, b, tolerance):
    R = []
    k = 0

    while True:
        n = 2**k
        h = (b-a)/n

        T = (f(a) + f(b))/2

        for i in range(1, n):
            T += f(a + i*h)

        T *= h

        row = [T]

        for j in range(1, k+1):
            value = row[j-1] + (row[j-1] - R[k-1][j-1])/(4**j - 1)
            row.append(value)

        R.append(row)

        if k > 0:
            difference = abs(R[k][k] - R[k-1][k-1])

            if difference < tolerance:
                break

        k += 1

    return R, difference

a = 0
b = 2
tolerance = 1e-10

R, difference = romberg(f, a, b, tolerance)

print("Romberg Table")

for i in range(len(R)):
    print("n =", 2**i, end="  ")
    for j in range(len(R[i])):
        print("%0.12f" % R[i][j], end="  ")
    print()

reference = 0.2593386854444973

print("\nFinal Approximation =", R[-1][-1])
print("Reference Value =", reference)
print("Absolute Error =", abs(R[-1][-1] - reference))
print("Final Difference =", difference)