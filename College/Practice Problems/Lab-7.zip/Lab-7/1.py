import matplotlib.pyplot as plt
import numpy as np

def exact_solution(t):
    return np.exp(-2 * t)

def explicit_euler(h, t_end=2.0, y0=1.0):
    N = int(round(t_end / h))
    t = np.linspace(0, t_end, N + 1)
    y = np.zeros(N + 1)
    y[0] = y0

    for i in range(N):
        y[i + 1] = y[i] + h * (-2 * y[i])

    return t, y

step_sizes = [0.2, 0.1, 0.05]
max_errors = {}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

t_fine = np.linspace(0, 2, 200)
ax1.plot(t_fine, exact_solution(t_fine), 'k-', linewidth=2, label='Exact: $e^{-2t}$')

for h in step_sizes:
    t, y_num = explicit_euler(h)
    y_ex = exact_solution(t)

    errors = np.abs(y_ex - y_num)

    max_errors[h] = np.max(errors)

    print(f'\n--- Results for step size h = {h} ---')
    print(f"{'t_i':<6} | {'y_num':<10} | {'y_exact':<10} | {'Error E_i':<10}")
    print('-' * 44)
    for ti, yn, ye, err in zip(t, y_num, y_ex, errors):
        print(f'{ti:<6.2f} | {yn:<10.6f} | {ye:<10.6f} | {err:<10.6f}')

    ax1.plot(t, y_num)

    ax2.plot(t, errors)

plt.show()

print('\n--- Convergence Analysis ---')
for h in step_sizes:
    print(f'h = {h:<5} -> E_max = {max_errors[h]:.6f}')

ratio_1 = max_errors[0.2] / max_errors[0.1]
ratio_2 = max_errors[0.1] / max_errors[0.05]

print(f'\nE_max(0.2) / E_max(0.1)  = {ratio_1:.4f}')
print(f'E_max(0.1) / E_max(0.05) = {ratio_2:.4f}')
