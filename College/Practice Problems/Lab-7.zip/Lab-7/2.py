import matplotlib.pyplot as plt
import numpy as np

def f(t, y):
    return -1000 * (y - np.cos(t)) - np.sin(t)

def exact_solution(t):
    return np.cos(t)

def explicit_euler(h, t_end=1.0, y0=1.0):
    N = int(round(t_end / h))
    t = np.linspace(0, t_end, N + 1)
    y = np.zeros(N + 1)
    y[0] = y0

    for i in range(N):
        y[i + 1] = y[i] + h * f(t[i], y[i])
        if np.abs(y[i + 1]) > 1e10:
            y[i + 1 :] = np.nan
            break
    return t, y

step_sizes = [0.01, 0.002, 0.001, 0.0005, 0.0001]

print(f"{'Step Size (h)':<15} | {'Steps (N)':<10} | {'Max Error (E_max)':<20}")
print('-' * 52)

fig, (ax1, ax2) = plt.subplots(1, 2)
t_fine = np.linspace(0, 1, 500)

t_unstable, y_unstable = explicit_euler(0.01)
ax1.plot(t_fine, exact_solution(t_fine))
ax1.plot(t_unstable[:15], y_unstable[:15])

ax2.plot(t_fine, exact_solution(t_fine))

for h in step_sizes:
    t, y_num = explicit_euler(h)
    y_ex = exact_solution(t)
    errors = np.abs(y_ex - y_num)

    e_max = np.nanmax(errors)
    N = int(round(1.0 / h))
    print(f'{h:<15} | {N:<10} | {e_max:<20.6e}')

    if h <= 0.002:
        ax2.plot(t, y_num)

plt.show()
