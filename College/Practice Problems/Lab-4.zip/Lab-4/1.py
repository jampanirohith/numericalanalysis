import math
import matplotlib.pyplot as plt

def f(x):
    return x**3 - x - 2

def bisection(f, a, b, max_iter=1000, tol=1e-10):
    if f(a) * f(b) >= 0:
        return None

    an = []
    bn = []
    pn = []

    for n in range(max_iter):
        p = (a + b) / 2.0
        an.append(a)
        bn.append(b)
        pn.append(p)

        if abs(f(p)) < tol or (b - a) / 2.0 < tol:
            break

        if f(p) * f(a) < 0:
            b = p
        else:
            a = p

    return an, bn, pn

a0 = 1.0
b0 = 2.0
tol = 1e-10

print("f(1) =", f(a0), "f(2) =", f(b0), "Product =", f(a0) * f(b0))

result = bisection(f, a0, b0, tol=tol)

if result is None:
    print("Bisection method fails.")
else:
    an, bn, pn = result
    root = pn[-1]
    print(f"Approximate root: {root:.12f}\n")

    for n in range(len(pn)):
        print(n, an[n], bn[n], pn[n], f(pn[n]), bn[n] - an[n])

    _, _, pn_exact = bisection(f, a0, b0, tol=1e-15)
    p_star = pn_exact[-1]

    n_values = list(range(len(pn)))
    actual_errors = []
    error_bounds = []
    bound_holds = True

    for n in n_values:
        err = abs(p_star - pn[n])
        bound = (b0 - a0) / (2**(n + 1))
        actual_errors.append(err)
        error_bounds.append(bound)
        if err > bound:
            bound_holds = False

    print("\nError bound holds:", bound_holds)

    min_iter = math.ceil(math.log2((b0 - a0) / tol))
    print("Theoretical min iterations:", min_iter)
    print("Actual iterations:", len(pn))

    plt.semilogy(n_values, actual_errors)
    plt.semilogy(n_values, error_bounds)
    plt.show()
