import math

def f(x):
  return x * math.cos(x) - 1

def secant(f, p0, p1, tol=1e-12, max_iter=100):
  history = [p0, p1]
  table = []

  for n in range(1, max_iter + 1):
    p_prev = history[-2]
    p_curr = history[-1]
    f_prev = f(p_prev)
    f_curr = f(p_curr)

    p_next = p_curr - f_curr * (p_curr - p_prev) / (f_curr - f_prev)

    table.append((n, p_prev, p_curr, f_curr, p_next))
    history.append(p_next)

    if abs(p_next - p_curr) < tol:
      break

  return p_next, table, history


root, table, history = secant_method(f, 0.0, 1.0, tol=1e-12)
