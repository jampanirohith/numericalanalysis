import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return np.exp(-x) - x

def df(x):
  return -np.exp(-x) - 1

p_star = 0.5671432904097838

def newtons(p0, tol=1e-12, max_iter=50):
  p_list = [p0]
  for _ in range(max_iter):
    pn = p_list[-1]
    p_next = pn - f(pn) / df(pn)
    p_list.append(p_next)
    if abs(p_next - pn) < tol:
      break
  return np.array(p_list)

p_vals = newtons(p0=0.5, tol=1e-12)
errors = np.abs(p_vals - p_star)

for n in range(len(p_vals)):
  print(
      f"n = {n}, p_n = {p_vals[n]:.15f}, f(p_n) = {f(p_vals[n]):.4e}, |p_n - p*|"
      f" = {errors[n]:.4e}, q_n = {q_vals[n]:.6f}"
  )

plt.semilogy(range(len(errors)), errors,)

plt.show()