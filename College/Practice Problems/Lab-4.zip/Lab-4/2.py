import math

def f(x):
    return x**3 + x - 1

def g1(x):
    return math.cbrt(1 - x)

def g2(x):
    return 1 - x**3

def g3(x):
    return 1 / (1 + x**2)

def fixedpoint(g, p0=0.5, tol=1e-10, max_iter=1000):
    p = p0
    for i in range(1, max_iter + 1):
        p_next = g(p)
        if abs(p_next - p) < tol:
            print(f"{g.__name__}: Converged in {i} iters | Root = {p_next:.10f} | Error = {abs(f(p_next)):.2e}")
            return p_next
        p = p_next
    print(f"{g.__name__}: Did not converge after {max_iter} iters")


for g in [g1, g2, g3]:
    fixedpoint(g)
