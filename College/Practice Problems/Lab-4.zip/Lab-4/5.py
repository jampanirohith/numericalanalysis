import math
import matplotlib.pyplot as plt
import mpmath as mp

mp.dps = 50
p_star = float(mp.findroot(lambda x: x**3 - 2 * x - 5, 2.5))
tol = 1e-10

def f(x):
  return x**3 - 2 * x - 5

def df(x):
  return 3 * x**2 - 2

def g(x):
  return (2 * x + 5) ** (1.0 / 3.0)

def bisection(a, b, tol):
  fa = f(a)
  fb = f(b)
  f_evals = 2
  table = []

  for n in range(1, 200):
    p = (a + b) / 2.0
    fp = f(p)
    f_evals += 1
    err = abs(p - p_star)
    table.append((n, a, b, p, fp, err))

    if (b - a) / 2.0 < tol or fp == 0:
      break
    if fa * fp < 0:
      b, fb = p, fp
    else:
      a, fa = p, fp

  return {
      "method": "Bisection",
      "root": p,
      "iters": len(table),
      "residual": abs(f(p)),
      "error": abs(p - p_star),
      "f_evals": f_evals,
      "df_evals": 0,
      "table": table,
  }


def fixed_point(p0, tol):
  p = p0
  f_evals = 0
  table = []

  for n in range(1, 200):
    p_next = g(p)
    f_evals += 1
    err = abs(p_next - p_star)
    table.append((n, p, p_next, abs(p_next - p), err))

    if abs(p_next - p) < tol:
      p = p_next
      break
    p = p_next

  return {
      "method": "Fixed-Point",
      "root": p,
      "iters": len(table),
      "residual": abs(f(p)),
      "error": abs(p - p_star),
      "f_evals": f_evals,
      "df_evals": 0,
      "table": table,
  }


def newton(p0, tol):
  p = p0
  f_evals = 0
  df_evals = 0
  table = []

  for n in range(1, 200):
    fx = f(p)
    dfx = df(p)
    f_evals += 1
    df_evals += 1

    p_next = p - fx / dfx
    err = abs(p_next - p_star)
    table.append((n, p, fx, dfx, p_next, abs(p_next - p), err))

    if abs(p_next - p) < tol:
      p = p_next
      break
    p = p_next

  return {
      "method": "Newton's",
      "root": p,
      "iters": len(table),
      "residual": abs(f(p)),
      "error": abs(p - p_star),
      "f_evals": f_evals,
      "df_evals": df_evals,
      "table": table,
  }


def secant(p0, p1, tol):
  f_prev = f(p0)
  f_curr = f(p1)
  f_evals = 2
  p_prev, p_curr = p0, p1
  table = []

  for n in range(1, 200):
    p_next = p_curr - f_curr * (p_curr - p_prev) / (f_curr - f_prev)
    f_next = f(p_next)
    f_evals += 1
    err = abs(p_next - p_star)
    table.append((n, p_prev, p_curr, f_curr, p_next, abs(p_next - p_curr), err))

    if abs(p_next - p_curr) < tol:
      p = p_next
      break
    p_prev, p_curr = p_curr, p_next
    f_prev, f_curr = f_curr, f_next

  return {
      "method": "Secant",
      "root": p,
      "iters": len(table),
      "residual": abs(f(p)),
      "error": abs(p - p_star),
      "f_evals": f_evals,
      "df_evals": 0,
      "table": table,
  }


res_bis = bisection(2.0, 3.0, tol)
res_fp = fixed_point(2.5, tol)
res_newt = newton(2.5, tol)
res_sec = secant(2.0, 3.0, tol)

print(f"Reference Root p* = {p_star:.16f}\n")

# Bisection Table
print("=== 1. BISECTION METHOD ===")
print(
    f"{'n':>3} | {'a_n':>14} | {'b_n':>14} | {'p_n':>14} | {'f(p_n)':>12} |"
    f" {'|p_n - p*|':>12}"
)
print("-" * 80)
for row in res_bis["table"]:
  print(
      f"{row[0]:3d} | {row[1]:14.10f} | {row[2]:14.10f} | {row[3]:14.10f} |"
      f" {row[4]:12.4e} | {row[5]:12.4e}"
  )

# Fixed-Point Table
print("\n=== 2. FIXED-POINT METHOD ===")
print(
    f"{'n':>3} | {'p_{n-1}':>14} | {'p_n':>14} | {'|p_n - p_{n-1}|':>15} |"
    f" {'|p_n - p*|':>12}"
)
print("-" * 70)
for row in res_fp["table"]:
  print(
      f"{row[0]:3d} | {row[1]:14.10f} | {row[2]:14.10f} | {row[3]:15.4e} |"
      f" {row[4]:12.4e}"
  )

# Newton's Table
print("\n=== 3. NEWTON'S METHOD ===")
print(
    f"{'n':>3} | {'p_{n-1}':>14} | {'f(p_{n-1})':>12} | {'f\'(p_{n-1})':>12} |"
    f" {'p_n':>14} | {'|p_n - p*|':>12}"
)
print("-" * 82)
for row in res_newt["table"]:
  print(
      f"{row[0]:3d} | {row[1]:14.10f} | {row[2]:12.4e} | {row[3]:12.4e} |"
      f" {row[4]:14.10f} | {row[6]:12.4e}"
  )

# Secant Table
print("\n=== 4. SECANT METHOD ===")
print(
    f"{'n':>3} | {'p_{n-1}':>14} | {'p_n':>14} | {'f(p_n)':>12} |"
    f" {'p_{n+1}':>14} | {'|p_{n+1} - p*|':>14}"
)
print("-" * 85)
for row in res_sec["table"]:
  print(
      f"{row[0]:3d} | {row[1]:14.10f} | {row[2]:14.10f} | {row[3]:12.4e} |"
      f" {row[4]:14.10f} | {row[6]:14.4e}"
  )

# ---------------------------------------------------------
# 4. Final Comparison Table (Tasks a - f)
# ---------------------------------------------------------
results = [res_bis, res_fp, res_newt, res_sec]
print("\n" + "=" * 96)
print("FINAL COMPARISON TABLE")
print("=" * 96)
print(
    f"{'Method':<13} | {'Approx. Root':<16} | {'Iters':<5} | {'|f(p_n)|':<11} |"
    f" {'|p_n - p*|':<11} | {'f Evals':<7} | {'f\' Evals':<8}"
)
print("-" * 96)
for r in results:
  print(
      f"{r['method']:<13} | {r['root']:<16.12f} | {r['iters']:<5d} |"
      f" {r['residual']:<11.4e} | {r['error']:<11.4e} | {r['f_evals']:<7d} |"
      f" {r['df_evals']:<8d}"
  )
print("=" * 96)

# ---------------------------------------------------------
# 5. Plot Error vs Iteration on Logarithmic Scale (Task h)
# ---------------------------------------------------------
plt.figure(figsize=(9, 5.5))

# Filter out exact 0.0 double-precision errors so log scale plots cleanly
plt.semilogy(
    [r[0] for r in res_bis["table"] if r[-1] > 0],
    [r[-1] for r in res_bis["table"] if r[-1] > 0],
    "o-",
    label="Bisection",
)
plt.semilogy(
    [r[0] for r in res_fp["table"] if r[-1] > 0],
    [r[-1] for r in res_fp["table"] if r[-1] > 0],
    "s-",
    label="Fixed-Point",
)
plt.semilogy(
    [r[0] for r in res_newt["table"] if r[-1] > 0],
    [r[-1] for r in res_newt["table"] if r[-1] > 0],
    "^-",
    label="Newton's Method",
)
plt.semilogy(
    [r[0] for r in res_sec["table"] if r[-1] > 0],
    [r[-1] for r in res_sec["table"] if r[-1] > 0],
    "d-",
    label="Secant Method",
)

plt.xlabel("Iteration Number (n)")
plt.ylabel("Actual Error |p_n - p*| (log scale)")
plt.title("Convergence Comparison: f(x) = x³ - 2x - 5 = 0")
plt.grid(True, which="both", linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()
plt.savefig("root_finding_comparison.png", dpi=300)
plt.show()
