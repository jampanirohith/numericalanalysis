import matplotlib.pyplot as plt
import numpy as np

def runge(x):
  return 1 / (1 + 25 * (x**2))

def df(x):
  return (-50 * x) / ((1 + 25 * (x**2)) ** 2)

def hermite(x_nodes, f_vals, df_vals, P):
  n = len(x_nodes)
  result = np.zeros_like(P, dtype=float)

  for i in range(n):
    L_i = np.ones_like(P, dtype=float)
    dL_i = 0.0

    for j in range(n):
      if j != i:
        L_i *= (P - x_nodes[j]) / (x_nodes[i] - x_nodes[j])
        dL_i += 1.0 / (x_nodes[i] - x_nodes[j])

    L_i_sq = L_i**2
    H_i = (1.0 - 2.0 * (P - x_nodes[i]) * dL_i) * L_i_sq
    K_i = (P - x_nodes[i]) * L_i_sq

    result += f_vals[i] * H_i + df_vals[i] * K_i

  return result

N = [5, 10, 20, 50, 300]
P = np.linspace(-1, 1, 5000)
f_exact = runge(P)

for N_values in N:
  x = np.linspace(-1, 1, N_values)
  f = runge(x)
  dF = df(x)

  y = hermite(x, f, dF, P)

  E_N = np.max(np.abs(f_exact - y))
  print(f"{N_values:<6} | {E_N:.6e}")

  plt.plot(P, f_exact)
  plt.plot(P, y)

  plt.show()
