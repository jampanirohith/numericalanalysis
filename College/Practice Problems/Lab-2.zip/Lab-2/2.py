import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return np.exp(-x) * np.sin(2 * x)

def naturalcubicspline(x_nodes, y_nodes, x_eval):
  n = len(x_nodes) - 1
  h = np.diff(x_nodes)

  A = np.zeros((n + 1, n + 1))
  b = np.zeros(n + 1)
  A[0, 0] = 1.0
  A[n, n] = 1.0

  for i in range(1, n):
    A[i, i - 1] = h[i - 1]
    A[i, i] = 2.0 * (h[i - 1] + h[i])
    A[i, i + 1] = h[i]
    b[i] = 6.0 * (
        (y_nodes[i + 1] - y_nodes[i]) / h[i]
        - (y_nodes[i] - y_nodes[i - 1]) / h[i - 1]
    )

  M = np.linalg.solve(A, b)

  x_eval = np.atleast_1d(x_eval)
  S = np.zeros_like(x_eval, dtype=float)

  for idx, x in enumerate(x_eval):
    i = np.clip(np.searchsorted(x_nodes, x) - 1, 0, n - 1)
    hi = h[i]
    dx1 = x_nodes[i + 1] - x
    dx2 = x - x_nodes[i]

    S[idx] = (
        M[i] * dx1**3 / (6.0 * hi)
        + M[i + 1] * dx2**3 / (6.0 * hi)
        + (y_nodes[i] - M[i] * hi**2 / 6.0) * dx1 / hi
        + (y_nodes[i + 1] - M[i + 1] * hi**2 / 6.0) * dx2 / hi
    )

  return S if S.size > 1 else S[0]

x_fine = np.linspace(0, 4, 2001)
y_exact = f(x_fine)
mesh_sizes = [0.5, 0.25, 0.125]
errors = []

plt.plot(x_fine, y_exact)

for h in mesh_sizes:
  x_nodes = np.arange(0, 4 + h / 2, h)
  y_nodes = f(x_nodes)

  y_spline = naturalcubicspline(x_nodes, y_nodes, x_fine)
  E_h = np.max(np.abs(y_exact - y_spline))
  errors.append(E_h)

  plt.plot(x_fine, y_spline, "--", label=f"Cubic Spline ($h = {h}$)")


print(f"{'h':<10}{'E_h':<18}{'E_h / E_{h/2}':<15}")
print("-" * 43)
for idx, h in enumerate(mesh_sizes):
  ratio = (
      f"{errors[idx] / errors[idx + 1]:.4f}"
      if idx < len(mesh_sizes) - 1
      else "—"
  )
  print(f"{h:<10}{errors[idx]:<18.4e}{ratio:<15}")

plt.show()
