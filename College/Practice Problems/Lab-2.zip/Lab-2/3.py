import matplotlib.pyplot as plt
import numpy as np

def f(x):
  return 1.0 / (1.0 + 25.0 * (x**2))

def naturalcubicspline(x_nodes, y_nodes, x_eval):
  n = len(x_nodes) - 1
  h = np.diff(x_nodes)

  A = np.zeros((n + 1, n + 1))
  b = np.zeros(n + 1)
  A = 1.0
  A[n, n] = 1.0

  for i in range(1, n):
    A[i, i - 1] = h[i - 1]
    A[i, i] = 2.0 * (h[i - 1] + h[i])
    A[i, i + 1] = h[i]
    b[i] = 6.0 * (
        (y_nodes[i + 1] - y_nodes[i]) / h[i]
        - (y_nodes[i] - y_nodes[i - 1]) / h[i - 1]
    )

  M = np.linalg.solve(A, b)

  x_eval = np.atleast_1d(x_eval)
  S = np.zeros_like(x_eval, dtype=float)

  for idx, x in enumerate(x_eval):
    i = np.clip(np.searchsorted(x_nodes, x) - 1, 0, n - 1)
    hi = h[i]
    dx_right = x_nodes[i + 1] - x
    dx_left = x - x_nodes[i]

    S[idx] = (
        M[i] * dx_right**3 / (6.0 * hi)
        + M[i + 1] * dx_left**3 / (6.0 * hi)
        + (y_nodes[i] - M[i] * hi**2 / 6.0) * (dx_right / hi)
        + (y_nodes[i + 1] - M[i + 1] * hi**2 / 6.0) * (dx_left / hi)
    )

  return S if S.size > 1 else S

N_values = [10, 20, 50]
x_fine = np.linspace(-1, 1, 2001)
f_fine = f(x_fine)

print(f"{'N':<10} | {'E_N^Spline':<20}")
print("-" * 30)

for idx, N in enumerate(N_values, 1):
  x_nodes = np.linspace(-1, 1, N + 1)
  y_nodes = f(x_nodes)

  S_fine = naturalcubicspline(x_nodes, y_nodes, x_fine)
  max_error = np.max(np.abs(f_fine - S_fine))

  print(f"{N:<10} | {max_error:<20.6e}")

  plt.subplot(2, 2, idx)
  plt.plot(x_fine, f_fine, "k-", linewidth=2, label="Exact $f(x)$")
  plt.plot(x_fine, S_fine, "r--", linewidth=1.5, label=f"Spline $S_{{{N}}}(x)$")
  plt.plot(x_nodes, y_nodes, "bo", markersize=4, label="Nodes")

plt.show()
