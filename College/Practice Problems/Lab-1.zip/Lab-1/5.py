import numpy as np
import matplotlib.pyplot as plt

def f(x):
    return 1 / (1 + x**2)

x = list(range(-5, 6))
y = [f(xi) for xi in x]
n = len(x)

a = list(y)
for j in range(1, n):
    for i in range(n - 1, j - 1, -1):
        a[i] = (a[i] - a[i - 1]) / (x[i] - x[i - j])

def newtoninterpolation(alpha):
    p = a[0]
    product = 1
    for i in range(1, n):
        product *= (alpha - x[i - 1])
        p += a[i] * product
    return p

for val in [4.2, 4.4, 4.6, 4.8]:
    error = abs(f(val) - newtoninterpolation(val))
    print(f"x = {val}: f(x) = {f(val):.6f}, p10(x) = {newtoninterpolation(val):.6f}, Error E = {error:.6f}")

x_plot = np.linspace(-5, 5, 500)
plt.plot(x_plot, f(x_plot))
plt.plot(x_plot, [newtoninterpolation(val) for val in x_plot])

plt.show()
