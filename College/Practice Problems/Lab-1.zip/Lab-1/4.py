x = [1, 2, 3, -4, 5]
y = [2, 48, 272, 1182, 2262]
n = len(x)

a = list(y)

for j in range(1, n):
    for i in range(n - 1, j - 1, -1):
        a[i] = (a[i] - a[i - 1]) / (x[i] - x[i - j])

def newtoninterpolation(alpha):
    p = a[0]
    product = 1
    for i in range(1, n):
        product *= (alpha - x[i - 1])
        p += a[i] * product
    return p

print("Coefficients a:", a)
print("p(-1) =", newtoninterpolation(-1))